#!/bin/bash

cd /usr/lib/savedata/
python savedata-restore.py $*
