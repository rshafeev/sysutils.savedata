#!/bin/bash

cd /usr/lib/savedata/
python savedata-backup.py $*
