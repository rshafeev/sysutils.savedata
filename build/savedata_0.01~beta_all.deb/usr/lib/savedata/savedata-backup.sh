#!/bin/bash

python savedata-backup.py